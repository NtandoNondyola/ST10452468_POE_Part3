package part1;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class MessageServiceTest {
    
    @Before
    public void setUp() {
        MessageManager.clearAll();
    }
    
    @Test
    public void testInitializeTestData() {
        MessageService.initializeTestData();
        
        assertTrue("Test data should be valid", MessageService.validateMessageData());
        assertEquals(2, MessageManager.getSentMessages().size());
        assertEquals(2, MessageManager.getStoredMessages().size());
        assertEquals(1, MessageManager.getDisregardedMessages().size());
    }
    
    @Test
    public void testGetFormattedSentMessages() {
        MessageService.initializeTestData();
        String formatted = MessageService.getFormattedSentMessages();
        
        assertTrue("Should contain cake message", formatted.contains("Did you get the cake?"));
        assertTrue("Should contain dinner message", formatted.contains("It is dinner time!"));
        assertFalse("Should not contain stored messages", formatted.contains("Where are you"));
    }
    
    @Test
    public void testValidateMessageData() {
        MessageService.initializeTestData();
        assertTrue("Validation should pass with correct test data", MessageService.validateMessageData());
        
        MessageManager.clearAll();
        assertFalse("Validation should fail with empty data", MessageService.validateMessageData());
    }
}