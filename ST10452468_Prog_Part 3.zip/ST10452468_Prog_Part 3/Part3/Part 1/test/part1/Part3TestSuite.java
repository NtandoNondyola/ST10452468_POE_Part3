package part1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    MessageTest.class,
    MessageManagerTest.class,
    MessageServiceTest.class
})
public class Part3TestSuite {
    // Test suite to run all Part 3 tests
}