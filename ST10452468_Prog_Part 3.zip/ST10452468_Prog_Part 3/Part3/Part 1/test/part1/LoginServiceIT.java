package part1;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class LoginServiceIT {
    private LoginService loginService;
    
    @Before
    public void setUp() {
        loginService = new LoginService();
        loginService.clearAllUsers(); // Clear before each test
    }
    
    @Test
    public void testUserRegistrationAndLogin() {
        // Register a user
        String result = loginService.registerUser("John", "Doe", "john_", "Test123!", "+27123456789");
        assertNull("Registration should succeed", result);
        
        // Test login with correct credentials
        assertTrue("Login should succeed with correct credentials", 
                   loginService.loginUser("john_", "Test123!"));
        
        // Test login with wrong password
        assertFalse("Login should fail with wrong password", 
                    loginService.loginUser("john_", "WrongPass!"));
    }
    
    @Test
    public void testLoginStatusMessages() {
        loginService.registerUser("John", "Doe", "john_", "Test123!", "+27123456789");
        
        String successStatus = loginService.returnLoginStatus("john_", "Test123!");
        assertTrue("Success status should contain welcome message", 
                   successStatus.contains("Welcome John, Doe"));
        
        String failStatus = loginService.returnLoginStatus("john_", "WrongPass!");
        assertEquals("Fail status should be correct", 
                     "Failed login. Please check your username and password.", failStatus);
    }
    
    @Test
    public void testUserDataRetrieval() {
        loginService.registerUser("John", "Doe", "john_", "Test123!", "+27123456789");
        
        String[] names = loginService.getUserNames("john_");
        assertNotNull("Should retrieve user names", names);
        assertEquals("First name should match", "John", names[0]);
        assertEquals("Last name should match", "Doe", names[1]);
    }
}