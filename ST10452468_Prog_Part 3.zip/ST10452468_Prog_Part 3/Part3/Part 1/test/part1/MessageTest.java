package part1;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class MessageTest {
    
    @Before
    public void setUp() {
        Message.resetCounter();
    }
    
    @Test
    public void testMessageCreation() {
        Message message = new Message(1, "+27123456789", "Test message");
        
        assertNotNull(message);
        assertEquals(1, message.getMessageNumber());
        assertEquals("+27123456789", message.getRecipient());
        assertEquals("Test message", message.getMessageText());
        assertNotNull(message.getMessageID());
        assertNotNull(message.getMessageHash());
    }
    
    @Test
    public void testMessageIDFormat() {
        Message message = new Message(1, "+27123456789", "Test");
        String messageID = message.getMessageID();
        
        assertNotNull(messageID);
        assertEquals(10, messageID.length());
        assertTrue(messageID.matches("\\d+"));
    }
    
    @Test
    public void testMessageHashFormat() {
        Message message = new Message(1, "+27123456789", "Hello World");
        String hash = message.getMessageHash();
        
        assertNotNull(hash);
        assertTrue(hash.matches("\\d{2}:\\d+:\\w+"));
        assertTrue(hash.contains(":"));
    }
    
    @Test
    public void testMultipleMessages() {
        Message msg1 = new Message(1, "+27123456789", "First");
        Message msg2 = new Message(2, "+27987654321", "Second");
        
        assertEquals(1, msg1.getMessageNumber());
        assertEquals(2, msg2.getMessageNumber());
        assertNotEquals(msg1.getMessageID(), msg2.getMessageID());
        assertNotEquals(msg1.getMessageHash(), msg2.getMessageHash());
    }
    
    @Test
    public void testMessageToString() {
        Message message = new Message(1, "+27123456789", "Test message");
        String str = message.toString();
        
        assertTrue(str.contains("Message #1"));
        assertTrue(str.contains("+27123456789"));
        assertTrue(str.contains("Test message"));
    }
}