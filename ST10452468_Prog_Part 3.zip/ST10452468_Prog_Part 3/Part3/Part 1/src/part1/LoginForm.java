package part1;

import javax.swing.*;
import java.awt.*;

public class LoginForm extends JFrame {
    private final JTextField userTextField;
    private final JPasswordField passwordField;
    private final JButton loginButton;
    private final JLabel messageLabel;
    private final LoginService loginService;

    public LoginForm(LoginService loginService) {
        this.loginService = loginService;
        
        setTitle("Login Form");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 40, 100, 25);
        userLabel.setForeground(new Color(0, 102, 204));
        add(userLabel);

        userTextField = new JTextField();
        userTextField.setBounds(150, 40, 180, 25);
        userTextField.setBackground(new Color(224, 235, 255));
        add(userTextField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 80, 100, 25);
        passwordLabel.setForeground(new Color(0, 102, 204));
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 80, 180, 25);
        passwordField.setBackground(new Color(224, 235, 255));
        add(passwordField);

        loginButton = new JButton("Login");
        loginButton.setBounds(150, 120, 100, 30);
        loginButton.setBackground(new Color(0, 102, 204));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        add(loginButton);

        messageLabel = new JLabel("");
        messageLabel.setBounds(50, 160, 300, 25);
        messageLabel.setForeground(Color.RED);
        add(messageLabel);

        loginButton.addActionListener(e -> loginAction());
    }

    private void loginAction() {
        String username = userTextField.getText().trim();
        String password = new String(passwordField.getPassword());

        String result = loginService.returnLoginStatus(username, password);
        if (result.startsWith("Welcome")) {
            setMessage(result, new Color(0, 153, 0));
            
            // Get user details for messaging
            String[] names = loginService.getUserNames(username);
            if (names != null) {
                // Open messaging form
                SwingUtilities.invokeLater(() -> {
                    MessagingForm messagingForm = new MessagingForm(names[0], names[1]);
                    messagingForm.setVisible(true);
                });
                
                // Close login form after a short delay
                Timer timer = new Timer(1000, evt -> dispose());
                timer.setRepeats(false);
                timer.start();
            }
        } else {
            setMessage(result, Color.RED);
        }
    }

    private void setMessage(String message, Color color) {
        messageLabel.setText(message);
        messageLabel.setForeground(color);
    }
}