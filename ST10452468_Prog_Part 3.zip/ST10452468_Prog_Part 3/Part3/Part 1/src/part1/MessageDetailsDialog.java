package part1;

import javax.swing.*;
import java.awt.*;

public class MessageDetailsDialog extends JDialog {
    
    public MessageDetailsDialog(JFrame parent, Message message) {
        super(parent, "Message Details", true);
        
        setSize(450, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204));
        JLabel titleLabel = new JLabel("Message Sent Successfully!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        add(titlePanel, BorderLayout.NORTH);

        // Details Panel
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new GridLayout(5, 1, 5, 10));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Message ID
        JPanel idPanel = createDetailPanel("Message ID:", message.getMessageID());
        detailsPanel.add(idPanel);

        // Message Number
        JPanel numberPanel = createDetailPanel("Message Number:", String.valueOf(message.getMessageNumber()));
        detailsPanel.add(numberPanel);

        // Recipient
        JPanel recipientPanel = createDetailPanel("Recipient:", message.getRecipient());
        detailsPanel.add(recipientPanel);

        // Content
        JPanel contentPanel = new JPanel(new BorderLayout(5, 5));
        JLabel contentLabel = new JLabel("Content:");
        contentLabel.setFont(new Font("Arial", Font.BOLD, 13));
        contentLabel.setForeground(new Color(0, 102, 204));
        
        JTextArea contentArea = new JTextArea(message.getContent());
        contentArea.setEditable(false);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setBackground(new Color(240, 240, 240));
        contentArea.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        JScrollPane scrollPane = new JScrollPane(contentArea);
        scrollPane.setPreferredSize(new Dimension(350, 60));
        
        contentPanel.add(contentLabel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        detailsPanel.add(contentPanel);

        // Message Hash
        JPanel hashPanel = createDetailPanel("Message Hash:", message.getMessageHash());
        detailsPanel.add(hashPanel);

        add(detailsPanel, BorderLayout.CENTER);

        // Close Button
        JPanel buttonPanel = new JPanel();
        JButton closeButton = new JButton("Close");
        closeButton.setBackground(new Color(0, 102, 204));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setPreferredSize(new Dimension(100, 35));
        closeButton.addActionListener(e -> dispose());
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createDetailPanel(String labelText, String valueText) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 13));
        label.setForeground(new Color(0, 102, 204));
        
        JTextField valueField = new JTextField(valueText);
        valueField.setEditable(false);
        valueField.setBackground(new Color(240, 240, 240));
        valueField.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(valueField, BorderLayout.CENTER);
        
        return panel;
    }
}