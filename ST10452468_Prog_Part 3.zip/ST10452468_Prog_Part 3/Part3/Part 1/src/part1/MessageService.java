package part1;

import java.util.List;

public class MessageService {
    
    public static void initializeTestData() {
        MessageManager.clearAll();
        
        // Test data from requirements
        Message msg1 = new Message(1, "+27834557896", "Did you get the cake?");
        Message msg2 = new Message(2, "+2783884567", "Where are you? You are late! I have asked you to be on time.");
        Message msg3 = new Message(3, "+27834484567", "Yohoooo, I am at your gate.");
        Message msg4 = new Message(4, "0838884567", "It is dinner time!");
        Message msg5 = new Message(5, "+2783884567", "Ok, I am leaving without you.");
        
        MessageManager.addMessage(msg1, "sent");
        MessageManager.addMessage(msg2, "stored");
        MessageManager.addMessage(msg3, "discarded");
        MessageManager.addMessage(msg4, "sent");
        MessageManager.addMessage(msg5, "stored");
    }
    
    public static String getFormattedSentMessages() {
        List<Message> sentMessages = MessageManager.getSentMessages();
        if (sentMessages.isEmpty()) {
            return "No sent messages";
        }
        
        StringBuilder sb = new StringBuilder();
        for (Message msg : sentMessages) {
            sb.append("\"").append(msg.getMessageText()).append("\", ");
        }
        return sb.substring(0, sb.length() - 2);
    }
    
    public static boolean validateMessageData() {
        List<Message> sent = MessageManager.getSentMessages();
        List<Message> stored = MessageManager.getStoredMessages();
        List<Message> disregarded = MessageManager.getDisregardedMessages();
        
        return sent.size() == 2 && stored.size() == 2 && disregarded.size() == 1;
    }
}