package part1;

import javax.swing.*;
import java.awt.*;

public class MessagingForm extends JFrame {
    private final String firstName;
    private final String lastName;
    private int totalMessagesToSend = 0;
    private int messagesSent = 0;

    public MessagingForm(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        
        setTitle("QuickChat - Messaging");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Welcome Panel
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(new Color(0, 102, 204));
        JLabel welcomeLabel = new JLabel("Welcome to QuickChat");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.WHITE);
        welcomePanel.add(welcomeLabel);
        add(welcomePanel, BorderLayout.NORTH);

        // Menu Panel
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(4, 1, 10, 10));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel menuLabel = new JLabel("Select an option:", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Arial", Font.BOLD, 14));
        menuPanel.add(menuLabel);

        // Button 1: Send Messages
        JButton btnSendMessages = new JButton("1. Send Messages");
        btnSendMessages.setBackground(new Color(0, 102, 204));
        btnSendMessages.setForeground(Color.WHITE);
        btnSendMessages.setFocusPainted(false);
        btnSendMessages.setFont(new Font("Arial", Font.PLAIN, 14));
        btnSendMessages.addActionListener(e -> handleSendMessages());
        menuPanel.add(btnSendMessages);

        // Button 2: Show Recently Sent Messages
        JButton btnShowMessages = new JButton("2. Show Recently Sent Messages");
        btnShowMessages.setBackground(new Color(0, 102, 204));
        btnShowMessages.setForeground(Color.WHITE);
        btnShowMessages.setFocusPainted(false);
        btnShowMessages.setFont(new Font("Arial", Font.PLAIN, 14));
        btnShowMessages.addActionListener(e -> showComingSoon());
        menuPanel.add(btnShowMessages);

        // Button 3: Quit
        JButton btnQuit = new JButton("3. Quit");
        btnQuit.setBackground(new Color(204, 0, 0));
        btnQuit.setForeground(Color.WHITE);
        btnQuit.setFocusPainted(false);
        btnQuit.setFont(new Font("Arial", Font.PLAIN, 14));
        btnQuit.addActionListener(e -> handleQuit());
        menuPanel.add(btnQuit);

        add(menuPanel, BorderLayout.CENTER);
    }

    private void handleSendMessages() {
        if (totalMessagesToSend == 0) {
            // Ask user how many messages they want to send
            String input = JOptionPane.showInputDialog(this, 
                "How many messages do you want to send?", 
                "Message Quantity", 
                JOptionPane.QUESTION_MESSAGE);
            
            if (input == null || input.trim().isEmpty()) {
                return; // User cancelled
            }
            
            try {
                totalMessagesToSend = Integer.parseInt(input.trim());
                if (totalMessagesToSend <= 0) {
                    JOptionPane.showMessageDialog(this, 
                        "Please enter a positive number.", 
                        "Invalid Input", 
                        JOptionPane.ERROR_MESSAGE);
                    totalMessagesToSend = 0;
                    return;
                }
                messagesSent = 0; // Reset counter
                openSendMessageForm();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid number.", 
                    "Invalid Input", 
                    JOptionPane.ERROR_MESSAGE);
            }
        } else if (messagesSent < totalMessagesToSend) {
            openSendMessageForm();
        } else {
            // All messages sent - show total
            int totalSent = Message.returnTotalMessages();
            JOptionPane.showMessageDialog(this, 
                "You have sent all " + totalMessagesToSend + " messages.\n" +
                "Total messages in system: " + totalSent, 
                "Messages Complete", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Reset for next session
            totalMessagesToSend = 0;
            messagesSent = 0;
        }
    }

    private void openSendMessageForm() {
        try {
            SendMessageForm sendForm = new SendMessageForm(this, firstName, lastName);
            sendForm.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error opening message form: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    public void incrementMessagesSent() {
        messagesSent++;
        
        // Check if all messages have been sent
        if (messagesSent >= totalMessagesToSend) {
            int totalSent = Message.returnTotalMessages();
            JOptionPane.showMessageDialog(this, 
                "You have completed sending all " + totalMessagesToSend + " messages!\n" +
                "Total messages in system: " + totalSent, 
                "All Messages Sent", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Reset for next session
            totalMessagesToSend = 0;
            messagesSent = 0;
        }
    }

    public int getRemainingMessages() {
        return totalMessagesToSend - messagesSent;
    }

    private void showComingSoon() {
        JOptionPane.showMessageDialog(this, 
            "Coming Soon!\nThis feature is under development.", 
            "Coming Soon", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleQuit() {
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to quit QuickChat?", 
            "Confirm Quit", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            int totalSent = Message.returnTotalMessages();
            if (totalSent > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Total messages sent this session: " + totalSent + "\nThank you for using QuickChat!", 
                    "Goodbye", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
            dispose();
        }
    }
}