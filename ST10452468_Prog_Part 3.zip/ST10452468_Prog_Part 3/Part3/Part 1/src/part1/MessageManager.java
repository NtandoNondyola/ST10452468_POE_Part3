package part1;

import java.util.ArrayList;
import java.util.List;

public class MessageManager {
    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIDs = new ArrayList<>();

    public static void clearAll() {
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        Message.resetCounter();
    }

    public static void addMessage(Message message, String action) {
        switch (action.toLowerCase()) {
            case "sent":
                sentMessages.add(message);
                break;
            case "stored":
                storedMessages.add(message);
                break;
            case "discarded":
            case "disregarded":
                disregardedMessages.add(message);
                break;
        }
        
        messageHashes.add(message.getMessageHash());
        messageIDs.add(message.getMessageID());
    }

    // Array getters
    public static List<Message> getSentMessages() { return new ArrayList<>(sentMessages); }
    public static List<Message> getStoredMessages() { return new ArrayList<>(storedMessages); }
    public static List<Message> getDisregardedMessages() { return new ArrayList<>(disregardedMessages); }
    public static List<String> getMessageHashes() { return new ArrayList<>(messageHashes); }
    public static List<String> getMessageIDs() { return new ArrayList<>(messageIDs); }

    // Feature 1: Display longest message
    public static String displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            return "No sent messages available.";
        }

        Message longest = sentMessages.get(0);
        for (Message msg : sentMessages) {
            if (msg.getMessageText().length() > longest.getMessageText().length()) {
                longest = msg;
            }
        }

        return String.format("Longest Message: '%s' (%d characters) sent to %s",
                longest.getMessageText(), longest.getMessageText().length(), longest.getRecipient());
    }

    // Feature 2: Search by message ID
    public static String searchByMessageID(String messageID) {
        for (Message msg : sentMessages) {
            if (msg.getMessageID().equals(messageID)) {
                return String.format("Message found:\nID: %s\nRecipient: %s\nMessage: %s",
                        msg.getMessageID(), msg.getRecipient(), msg.getMessageText());
            }
        }
        return "Message with ID " + messageID + " not found.";
    }

    // Feature 3: Search by recipient
    public static String searchByRecipient(String recipient) {
        List<Message> results = new ArrayList<>();
        for (Message msg : sentMessages) {
            if (msg.getRecipient().equals(recipient)) {
                results.add(msg);
            }
        }

        if (results.isEmpty()) {
            return "No messages found for recipient: " + recipient;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Messages for ").append(recipient).append(":\n");
        for (Message msg : results) {
            sb.append("- ").append(msg.getMessageText()).append("\n");
        }
        return sb.toString();
    }

    // Feature 4: Delete by message hash
    public static String deleteByMessageHash(String messageHash) {
        // Search in sent messages
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).getMessageHash().equals(messageHash)) {
                Message removed = sentMessages.remove(i);
                messageHashes.remove(messageHash);
                messageIDs.remove(removed.getMessageID());
                return "Message successfully deleted: " + removed.getMessageText();
            }
        }

        // Search in stored messages
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).getMessageHash().equals(messageHash)) {
                Message removed = storedMessages.remove(i);
                messageHashes.remove(messageHash);
                messageIDs.remove(removed.getMessageID());
                return "Message successfully deleted: " + removed.getMessageText();
            }
        }

        return "Message with hash " + messageHash + " not found.";
    }

    // Feature 5: Display message report
    public static String displayMessageReport() {
        if (sentMessages.isEmpty() && storedMessages.isEmpty()) {
            return "No messages to display in report.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("MESSAGE REPORT\n");
        sb.append("==============\n\n");

        if (!sentMessages.isEmpty()) {
            sb.append("SENT MESSAGES:\n");
            for (Message msg : sentMessages) {
                sb.append(String.format("Hash: %s | To: %s | Message: %s\n",
                        msg.getMessageHash(), msg.getRecipient(), msg.getMessageText()));
            }
            sb.append("\n");
        }

        if (!storedMessages.isEmpty()) {
            sb.append("STORED MESSAGES:\n");
            for (Message msg : storedMessages) {
                sb.append(String.format("Hash: %s | To: %s | Message: %s\n",
                        msg.getMessageHash(), msg.getRecipient(), msg.getMessageText()));
            }
            sb.append("\n");
        }

        sb.append("SUMMARY:\n");
        sb.append("Total Sent Messages: ").append(sentMessages.size()).append("\n");
        sb.append("Total Stored Messages: ").append(storedMessages.size()).append("\n");
        sb.append("Total Disregarded Messages: ").append(disregardedMessages.size()).append("\n");
        sb.append("Total Message Hashes: ").append(messageHashes.size()).append("\n");
        sb.append("Total Message IDs: ").append(messageIDs.size());

        return sb.toString();
    }

    // Feature 6: Display sent messages details
    public static String displaySentMessagesDetails() {
        if (sentMessages.isEmpty()) {
            return "No sent messages available.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("SENT MESSAGES DETAILS\n");
        sb.append("=====================\n\n");

        for (Message msg : sentMessages) {
            sb.append(String.format("Message #%d\n", msg.getMessageNumber()));
            sb.append("ID: ").append(msg.getMessageID()).append("\n");
            sb.append("Recipient: ").append(msg.getRecipient()).append("\n");
            sb.append("Message: ").append(msg.getMessageText()).append("\n");
            sb.append("Hash: ").append(msg.getMessageHash()).append("\n");
            sb.append("------------------------\n");
        }

        return sb.toString();
    }

    // Load from JSON (stub implementation)
    public static void loadStoredMessagesFromJSON() {
        // This would typically load from a JSON file
        // For testing purposes, we'll add some test data
        System.out.println("Loading messages from JSON...");
    }
}