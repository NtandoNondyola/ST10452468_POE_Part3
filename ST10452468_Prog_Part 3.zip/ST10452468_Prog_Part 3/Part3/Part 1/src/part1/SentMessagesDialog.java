package part1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SentMessagesDialog extends JDialog {
    private final List<Message> sentMessages;

    public SentMessagesDialog(JFrame parent, List<Message> sentMessages) {
        super(parent, "Recently Sent Messages", true);
        this.sentMessages = sentMessages;
        
        initializeUI();
        populateMessages();
    }

    private void initializeUI() {
        setSize(600, 400);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout(10, 10));
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204));
        JLabel titleLabel = new JLabel("Recently Sent Messages");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        add(titlePanel, BorderLayout.NORTH);

        // Messages Panel
        JPanel messagesPanel = createMessagesPanel();
        add(messagesPanel, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createMessagesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        if (sentMessages.isEmpty()) {
            JLabel noMessagesLabel = new JLabel("No sent messages found.", SwingConstants.CENTER);
            noMessagesLabel.setFont(new Font("Arial", Font.ITALIC, 14));
            noMessagesLabel.setForeground(Color.GRAY);
            panel.add(noMessagesLabel, BorderLayout.CENTER);
            return panel;
        }

        // Create table model
        String[] columnNames = {"#", "Message ID", "Recipient", "Message", "Hash"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };

        // Populate table with messages
        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            model.addRow(new Object[]{
                i + 1,
                msg.getMessageID(),
                msg.getRecipient(),
                formatMessageText(msg.getMessageText()),
                msg.getMessageHash()
            });
        }

        // Create table
        JTable table = new JTable(model);
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Set column widths
        table.getColumnModel().getColumn(0).setPreferredWidth(30);  // #
        table.getColumnModel().getColumn(1).setPreferredWidth(100); // Message ID
        table.getColumnModel().getColumn(2).setPreferredWidth(100); // Recipient
        table.getColumnModel().getColumn(3).setPreferredWidth(250); // Message
        table.getColumnModel().getColumn(4).setPreferredWidth(120); // Hash

        // Enable scrolling
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(580, 300));

        // Add summary label
        JLabel summaryLabel = new JLabel(
            String.format("Total sent messages: %d", sentMessages.size())
        );
        summaryLabel.setFont(new Font("Arial", Font.BOLD, 12));
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        panel.add(summaryLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        // View Details Button
        JButton btnDetails = new JButton("View Selected Message Details");
        btnDetails.setBackground(new Color(0, 102, 204));
        btnDetails.setForeground(Color.WHITE);
        btnDetails.setFocusPainted(false);
        btnDetails.addActionListener(e -> showSelectedMessageDetails());

        // Refresh Button
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setBackground(new Color(0, 153, 0));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.addActionListener(e -> refreshMessages());

        // Close Button
        JButton btnClose = new JButton("Close");
        btnClose.setBackground(new Color(204, 0, 0));
        btnClose.setForeground(Color.WHITE);
        btnClose.setFocusPainted(false);
        btnClose.addActionListener(e -> dispose());

        panel.add(btnDetails);
        panel.add(btnRefresh);
        panel.add(btnClose);

        return panel;
    }

    private String formatMessageText(String text) {
        if (text.length() > 50) {
            return text.substring(0, 47) + "...";
        }
        return text;
    }

    private void showSelectedMessageDetails() {
        // This would show details of a selected message
        // For now, show a summary of all messages
        StringBuilder details = new StringBuilder();
        details.append("MESSAGE DETAILS SUMMARY\n");
        details.append("=======================\n\n");
        
        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            details.append(String.format("Message #%d:\n", i + 1));
            details.append(String.format("  ID: %s\n", msg.getMessageID()));
            details.append(String.format("  To: %s\n", msg.getRecipient()));
            details.append(String.format("  Message: %s\n", msg.getMessageText()));
            details.append(String.format("  Hash: %s\n", msg.getMessageHash()));
            details.append("  --------------------\n");
        }
        
        JTextArea textArea = new JTextArea(details.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Message Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void refreshMessages() {
        // Reload messages from MessageManager
        List<Message> updatedMessages = MessageManager.getSentMessages();
        
        if (updatedMessages.size() != sentMessages.size()) {
            JOptionPane.showMessageDialog(this,
                "Messages refreshed!\n\n" +
                "Previous count: " + sentMessages.size() + "\n" +
                "Current count: " + updatedMessages.size(),
                "Refresh Complete",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Close and reopen to show updated list
            dispose();
            SentMessagesDialog newDialog = new SentMessagesDialog((JFrame) getParent(), updatedMessages);
            newDialog.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this,
                "No new messages found.",
                "No Changes",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Alternative simple version using JTextArea (uncomment if you prefer this)
    private JPanel createSimpleMessagesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        textArea.setBackground(new Color(240, 240, 240));

        StringBuilder content = new StringBuilder();
        content.append("RECENTLY SENT MESSAGES\n");
        content.append("======================\n\n");

        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            content.append(String.format("Message #%d\n", i + 1));
            content.append(String.format("ID: %s\n", msg.getMessageID()));
            content.append(String.format("To: %s\n", msg.getRecipient()));
            content.append(String.format("Message: %s\n", msg.getMessageText()));
            content.append(String.format("Hash: %s\n", msg.getMessageHash()));
            content.append("------------------------\n\n");
        }

        content.append(String.format("Total: %d messages", sentMessages.size()));
        textArea.setText(content.toString());

        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void populateMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}