package part1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class SendMessageForm extends JFrame {
    private JTextField recipientField;
    private JTextArea contentArea;
    private JLabel charCountLabel;
    private JButton btnSend;
    private JButton btnDiscard;
    private JButton btnStore;
    private final MessagingForm parent;
    private final String firstName;
    private final String lastName;

    public SendMessageForm(MessagingForm parent, String firstName, String lastName) {
        this.parent = parent;
        this.firstName = firstName;
        this.lastName = lastName;
        
        initializeUI();
        setupAutoFormatting();
    }

    private void initializeUI() {
        setTitle("Send Message - QuickChat");
        setSize(500, 500);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title panel
        JPanel titlePanel = createTitlePanel();
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Form panel
        JPanel formPanel = createFormPanel();
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = createButtonPanel();
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }

    private JPanel createTitlePanel() {
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JLabel titleLabel = new JLabel("Create New Message", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0, 102, 204));
        
        int remaining = parent != null ? parent.getRemainingMessages() : 0;
        JLabel remainingLabel = new JLabel("Messages remaining: " + remaining, SwingConstants.CENTER);
        remainingLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        remainingLabel.setForeground(Color.GRAY);
        
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(remainingLabel, BorderLayout.CENTER);
        
        return titlePanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        // Recipient section
        JPanel recipientPanel = createRecipientPanel();
        formPanel.add(recipientPanel);
        formPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Message content section
        JPanel contentPanel = createContentPanel();
        formPanel.add(contentPanel);
        
        return formPanel;
    }

    private JPanel createRecipientPanel() {
        JPanel recipientPanel = new JPanel(new BorderLayout(5, 5));
        
        JLabel recipientLabel = new JLabel("Recipient Cell Number:");
        recipientLabel.setFont(new Font("Arial", Font.BOLD, 12));
        recipientLabel.setForeground(new Color(0, 102, 204));
        
        recipientField = new JTextField();
        recipientField.setFont(new Font("Arial", Font.PLAIN, 12));
        recipientField.setPreferredSize(new Dimension(300, 30));
        recipientField.setBackground(new Color(240, 245, 255));
        recipientField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        recipientField.setToolTipText("Format: +27XXXXXXXXX (Example: +27718693002)");
        
        JLabel formatLabel = new JLabel("Required format: +27XXXXXXXXX (Example: +27718693002)");
        formatLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        formatLabel.setForeground(Color.GRAY);
        
        recipientPanel.add(recipientLabel, BorderLayout.NORTH);
        recipientPanel.add(recipientField, BorderLayout.CENTER);
        recipientPanel.add(formatLabel, BorderLayout.SOUTH);
        
        return recipientPanel;
    }

    private JPanel createContentPanel() {
        JPanel contentPanel = new JPanel(new BorderLayout(5, 5));
        
        JLabel contentLabel = new JLabel("Message Content:");
        contentLabel.setFont(new Font("Arial", Font.BOLD, 12));
        contentLabel.setForeground(new Color(0, 102, 204));
        
        contentArea = new JTextArea(6, 30);
        contentArea.setFont(new Font("Arial", Font.PLAIN, 12));
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setBackground(new Color(240, 245, 255));
        contentArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        JScrollPane scrollPane = new JScrollPane(contentArea);
        scrollPane.setPreferredSize(new Dimension(400, 120));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        charCountLabel = new JLabel("0 / 250 characters");
        charCountLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        charCountLabel.setForeground(Color.GRAY);
        
        contentPanel.add(contentLabel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(charCountLabel, BorderLayout.SOUTH);
        
        return contentPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        btnSend = createButton("Send Message", new Color(0, 153, 0), "send");
        btnStore = createButton("Store for Later", new Color(255, 153, 0), "store");
        btnDiscard = createButton("Discard", new Color(204, 0, 0), "discard");
        
        buttonPanel.add(btnSend);
        buttonPanel.add(btnStore);
        buttonPanel.add(btnDiscard);
        
        return buttonPanel;
    }

    private JButton createButton(String text, Color color, String action) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setPreferredSize(new Dimension(130, 40));
        
        // Add hover effects
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        button.addActionListener(e -> handleAction(action));
        
        return button;
    }

    private void setupAutoFormatting() {
        // Character count update
        contentArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                updateCharCount();
            }
        });
        
        // Phone number auto-format
        recipientField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                autoFormatPhoneNumber();
            }
        });
    }

    private void updateCharCount() {
        int length = contentArea.getText().length();
        charCountLabel.setText(length + " / 250 characters");
        
        if (length > 250) {
            charCountLabel.setForeground(Color.RED);
            charCountLabel.setFont(new Font("Arial", Font.BOLD, 10));
        } else if (length > 200) {
            charCountLabel.setForeground(Color.ORANGE);
            charCountLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        } else {
            charCountLabel.setForeground(Color.GRAY);
            charCountLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        }
    }

    private void autoFormatPhoneNumber() {
        String phone = recipientField.getText().trim();
        
        if (phone.isEmpty()) return;
        
        // Remove any existing formatting
        phone = phone.replaceAll("[^0-9+]", "");
        
        // Auto-format: 0765432178 -> +2765432178
        if (phone.matches("0[0-9]{9}")) {
            String formatted = "+27" + phone.substring(1);
            recipientField.setText(formatted);
            showInfoMessage("Phone number auto-formatted to: " + formatted);
        }
        // Add + if missing for international numbers
        else if (phone.matches("27[0-9]{9}")) {
            String formatted = "+" + phone;
            recipientField.setText(formatted);
            showInfoMessage("Phone number auto-formatted to: " + formatted);
        }
    }

    private void handleAction(String action) {
        String recipient = recipientField.getText().trim();
        String content = contentArea.getText().trim();

        // Validation
        if (!validateInput(recipient, content)) {
            return;
        }

        // Create and process message
        processMessage(recipient, content, action);
    }

    private boolean validateInput(String recipient, String content) {
        // Check for empty fields
        if (recipient.isEmpty() || content.isEmpty()) {
            showErrorMessage("Please fill in all fields.", "Incomplete Information");
            return false;
        }

        // Validate recipient format
        if (!isValidPhoneNumber(recipient)) {
            showErrorMessage(
                """
                Invalid phone number format!
                
                You entered: """ + recipient + "\n" +
                "Required format: +27XXXXXXXXX (11 digits total)\n" +
                "Example: +27718693002\n\n" +
                "Please correct the number and try again.",
                "Invalid Recipient"
            );
            return false;
        }

        // Validate content length
        if (content.length() > 250) {
            showErrorMessage(
                "Message is too long!\n\n" +
                "Current length: " + content.length() + " characters\n" +
                "Maximum allowed: 250 characters\n\n" +
                "Please shorten your message.",
                "Message Too Long"
            );
            return false;
        }

        return true;
    }

    private boolean isValidPhoneNumber(String phone) {
        return phone.matches("^\\+27[0-9]{9}$");
    }

    private void processMessage(String recipient, String content, String action) {
        try {
            // Create message object
            Message message = new Message(
                MessageManager.getSentMessages().size() + MessageManager.getStoredMessages().size() + 1,
                recipient,
                content
            );

            String result;
            String title;
            int messageType;

            switch (action.toLowerCase()) {
                case "send":
                    MessageManager.addMessage(message, "sent");
                    result = "Message sent successfully!\n\n" + getMessageDetails(message);
                    title = "Message Sent";
                    messageType = JOptionPane.INFORMATION_MESSAGE;
                    
                    // Update parent if available
                    if (parent != null) {
                        parent.incrementMessagesSent();
                    }
                    break;
                    
                case "store":
                    MessageManager.addMessage(message, "stored");
                    result = "Message stored for later.\n\n" + getMessageDetails(message);
                    title = "Message Stored";
                    messageType = JOptionPane.INFORMATION_MESSAGE;
                    
                    if (parent != null) {
                        parent.incrementMessagesSent();
                    }
                    break;
                    
                case "discard":
                    int confirm = JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to discard this message?\n\n" +
                        "Recipient: " + recipient + "\n" +
                        "Message: " + (content.length() > 50 ? content.substring(0, 50) + "..." : content),
                        "Confirm Discard",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                    );
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        result = "Message discarded.";
                        title = "Message Discarded";
                        messageType = JOptionPane.INFORMATION_MESSAGE;
                    } else {
                        return; // User cancelled
                    }
                    break;
                    
                default:
                    showErrorMessage("Unknown action: " + action, "Error");
                    return;
            }

            // Show result
            JOptionPane.showMessageDialog(this, result, title, messageType);
            
            // Close form for send and store actions
            if (!action.equalsIgnoreCase("discard")) {
                dispose();
            } else {
                // For discard, clear fields but keep form open
                clearFields();
            }

        } catch (Exception e) {
            showErrorMessage("Error processing message: " + e.getMessage(), "Error");
        }
    }

    private String getMessageDetails(Message message) {
        return "Message Details:\n" +
               "Recipient: " + message.getRecipient() + "\n" +
               "Message: " + message.getMessageText() + "\n" +
               "Message ID: " + message.getMessageID() + "\n" +
               "Message Hash: " + message.getMessageHash();
    }

    private void clearFields() {
        recipientField.setText("");
        contentArea.setText("");
        updateCharCount();
    }

    private void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    private void showInfoMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    // Public method to simulate sending message for testing
    public boolean sendTestMessage(String recipient, String content) {
        recipientField.setText(recipient);
        contentArea.setText(content);
        return validateInput(recipient, content);
    }
}